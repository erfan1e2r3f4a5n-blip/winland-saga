# Winland Saga architecture

## Layers
- `lib/app` theme, router, constants
- `lib/shared` reusable widgets
- `lib/core` database, profiles, backup, notifications, launcher, overlay, search, data_update
- `lib/modules` module registry (each feature is a switchable module)
- `lib/features` one folder per screen/feature

## Global search
Each feature provides a `SearchSource`. All entries are loaded into one in-memory
index (normalized text: lowercase, Persian/Arabic letter variants unified).
Results are grouped by type with filter chips. The index rebuilds after data updates.

## Data updates (independent of the APK)
1. The app ships with bundled data packs in `assets/data/` (works offline).
2. A `manifest.json` is hosted online (e.g. GitHub Pages). It lists packs:
   `name, version, schema, url, sha256, minAppVersion`.
3. On launch (and on "Check for updates") the app compares versions and
   downloads only newer packs, one pack per dataset: candles, spirits, events,
   quests, prices, locations.
4. Each download is verified (sha256) and schema-checked, then saved to the app
   storage atomically. The previous good copy is kept for rollback.
5. At runtime the app reads the newest valid pack, else the bundled one.
6. Packs with a newer `schema` than the app supports are skipped, with a
   message asking the user to update the app.
