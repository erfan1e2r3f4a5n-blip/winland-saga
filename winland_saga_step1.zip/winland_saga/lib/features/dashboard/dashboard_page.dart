import 'package:flutter/material.dart';
import '../../app/constants.dart';
import '../../app/theme.dart';
import '../../shared/page_chrome.dart';
import '../../shared/ws_card.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const PageHeader(title: AppConstants.appName, subtitle: 'Sky companion'),
        _ProfileBar(),
        const _SectionLabel('Play'),
        _PlayButton(label: 'Google Play | Global', onTap: () => showSoon(context, 'step 8')),
        _PlayButton(label: 'Google Play | Vietnamese', onTap: () => showSoon(context, 'step 8')),
        _PlayButton(label: 'AppGallery | Huawei', onTap: () => showSoon(context, 'step 8')),
        const _SectionLabel('Today'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.25,
            children: const [
              _StatCard(Icons.local_fire_department_rounded, 'Candles', '--', 'Step 4'),
              _StatCard(Icons.trending_up_rounded, 'Daily progress', '--', 'Step 4'),
              _StatCard(Icons.checklist_rounded, 'Quests left', '--', 'Step 4'),
              _StatCard(Icons.event_rounded, 'Next event', '--', 'Step 5'),
              _StatCard(Icons.flight_rounded, 'Next Traveling Spirit', '--', 'Step 5'),
              _StatCard(Icons.bolt_rounded, 'Next Shard', '--', 'Step 5'),
            ],
          ),
        ),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
        child: Text(text,
            style: const TextStyle(
                color: WsColors.textDim, fontWeight: FontWeight.w700)),
      );
}

class _ProfileBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: WsCard(
          onTap: () => showSoon(context, 'step 2'),
          child: Row(
            children: [
              const CircleAvatar(
                backgroundColor: WsColors.surfaceHigh,
                child: Icon(Icons.person_rounded, color: WsColors.teal),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Default profile',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    Text('Tap to switch or add a profile',
                        style: TextStyle(color: WsColors.textDim, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.swap_horiz_rounded, color: WsColors.textDim),
            ],
          ),
        ),
      );
}

class _PlayButton extends StatelessWidget {
  const _PlayButton({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        child: WsCard(
          onTap: onTap,
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.play_arrow_rounded, color: WsColors.teal),
              const SizedBox(width: 8),
              Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, letterSpacing: 0.3)),
            ],
          ),
        ),
      );
}

class _StatCard extends StatelessWidget {
  const _StatCard(this.icon, this.label, this.value, this.step);
  final IconData icon;
  final String label;
  final String value;
  final String step;
  @override
  Widget build(BuildContext context) => WsCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: WsColors.amber, size: 22),
            const Spacer(),
            Text(value,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: WsColors.textDim, fontSize: 13)),
          ],
        ),
      );
}
