import 'package:flutter/material.dart';
import '../../app/constants.dart';
import '../../app/theme.dart';
import '../../shared/page_chrome.dart';
import '../../shared/ws_card.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    Widget row(IconData icon, String title, String value, [String? step]) =>
        ListTile(
          leading: Icon(icon, color: WsColors.teal),
          title: Text(title),
          trailing: Text(value, style: const TextStyle(color: WsColors.textDim)),
          onTap: step == null ? null : () => showSoon(context, step),
        );

    return SubPage(
      title: 'Settings',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          WsCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                row(Icons.dark_mode_rounded, 'Theme', 'Dark'),
                row(Icons.language_rounded, 'Language', 'English', 'step 8'),
                row(Icons.notifications_rounded, 'Notifications', 'Off', 'step 5'),
                row(Icons.backup_rounded, 'Backup and restore', '', 'step 2'),
                row(Icons.cloud_sync_rounded, 'Data updates', 'Built-in', 'step 3'),
                row(Icons.picture_in_picture_alt_rounded, 'Floating Assistant', 'Off', 'step 8'),
              ],
            ),
          ),
          const SizedBox(height: 16),
          WsCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('${AppConstants.appName} ${AppConstants.version}',
                    style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 6),
                Text(
                  'A fan-made helper for Sky: Children of the Light players. '
                  'It does not connect to or change the game and is not '
                  'affiliated with thatgamecompany.',
                  style: TextStyle(color: WsColors.textDim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
