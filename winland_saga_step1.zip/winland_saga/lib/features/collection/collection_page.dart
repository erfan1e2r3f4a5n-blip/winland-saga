import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class CollectionPage extends StatelessWidget {
  const CollectionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubPage(
      title: 'Collection',
      child: ComingSoon(
        icon: Icons.inventory_2_rounded,
        title: 'Collection Tracker',
        description: 'Record what you own and see how complete you are.',
        step: 'step 6',
        features: ['Cape, Hair, Mask, Instrument, Accessory, Spell','Completion percentage per category'],
      ),
    );
  }
}
