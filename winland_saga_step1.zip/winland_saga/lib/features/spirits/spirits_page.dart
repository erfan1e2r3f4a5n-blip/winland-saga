import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class SpiritsPage extends StatelessWidget {
  const SpiritsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubPage(
      title: 'Traveling Spirits',
      child: ComingSoon(
        icon: Icons.flight_rounded,
        title: 'Spirit Tracker',
        description: 'Items, prices and what you already own.',
        step: 'step 6',
        features: ['Items and prices per spirit','Mark items you own','Total cost still needed'],
      ),
    );
  }
}
