import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../shared/page_chrome.dart';
import '../../shared/ws_card.dart';

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    const items = <(IconData, String, String, String)>[
      (Icons.local_fire_department_rounded, 'Candles', 'Count and plan', '/candles'),
      (Icons.flight_rounded, 'Traveling Spirits', 'Items and prices', '/spirits'),
      (Icons.inventory_2_rounded, 'Collection', 'What you own', '/collection'),
      (Icons.alt_route_rounded, 'Route Builder', 'Plan your run', '/routes'),
      (Icons.groups_rounded, 'Community', 'Modules and links', '/community'),
      (Icons.settings_rounded, 'Settings', 'Theme, alerts, backup', '/settings'),
    ];
    return SubPage(
      title: 'More',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final i in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: WsCard(
                onTap: () => context.push(i.$4),
                child: Row(
                  children: [
                    Icon(i.$1, color: WsColors.teal),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(i.$2,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 16)),
                          Text(i.$3,
                              style: const TextStyle(color: WsColors.textDim)),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right_rounded,
                        color: WsColors.textDim),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
