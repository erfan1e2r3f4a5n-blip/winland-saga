import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class RouteBuilderPage extends StatelessWidget {
  const RouteBuilderPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubPage(
      title: 'Route Builder',
      child: ComingSoon(
        icon: Icons.alt_route_rounded,
        title: 'Route Builder',
        description: 'Pick a goal and get an ordered list of steps.',
        step: 'step 7',
        features: ['Fastest candle route for today','Step-by-step checklist','Uses data from the Map'],
      ),
    );
  }
}
