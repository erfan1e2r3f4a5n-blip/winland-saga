import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class MapPage extends StatelessWidget {
  const MapPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        PageHeader(title: 'Map', subtitle: 'Worlds of Sky'),
        Expanded(
          child: ComingSoon(
            icon: Icons.map_rounded,
            title: 'Interactive Map',
            description: 'Browse each realm and find what you need.',
            step: 'step 7',
            features: ['Candles, spirits, Winged Light, events','Search on the map','Add places to a route'],
          ),
        ),
      ],
    );
  }
}
