import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

/// Global search UI. The real index (core/search) is wired up in step 4+.
class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SubPage(
      title: 'Search',
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              autofocus: true,
              decoration: InputDecoration(
                hintText: 'Search spirits, items, places, events, quests...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
          ),
          const Expanded(
            child: ComingSoon(
              icon: Icons.manage_search_rounded,
              title: 'Search everything',
              description:
                  'One box for spirits, items, locations, events, candles and quests.',
              step: 'step 4 and later',
              features: ['Results grouped by type', 'Works offline', 'Updates with new data'],
            ),
          ),
        ],
      ),
    );
  }
}
