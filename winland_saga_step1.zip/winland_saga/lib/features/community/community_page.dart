import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class CommunityPage extends StatelessWidget {
  const CommunityPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubPage(
      title: 'Community',
      child: ComingSoon(
        icon: Icons.groups_rounded,
        title: 'Community',
        description: 'Shared modules and useful links.',
        step: 'step 3',
        features: ['Browse shared modules','Links and guides'],
      ),
    );
  }
}
