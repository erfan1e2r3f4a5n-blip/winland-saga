import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/theme.dart';
import '../../modules/module_registry.dart';
import '../../shared/page_chrome.dart';
import '../../shared/ws_card.dart';

class ModulesPage extends ConsumerWidget {
  const ModulesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final modules = ref.watch(modulesProvider);
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const PageHeader(title: 'Modules', subtitle: 'Switch features on or off'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: WsCard(
                  onTap: () => showSoon(context, 'step 3'),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  child: const Center(
                    child: Text('ADD MODULE',
                        style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 64,
                child: WsCard(
                  onTap: () => showSoon(context, 'step 3'),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: const Center(
                    child: Icon(Icons.help_outline_rounded),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        for (final m in modules)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: _ModuleCard(module: m),
          ),
      ],
    );
  }
}

class _ModuleCard extends ConsumerWidget {
  const _ModuleCard({required this.module});
  final ModuleInfo module;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return WsCard(
      borderColor: module.enabled ? WsColors.teal.withOpacity(0.5) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: WsColors.surfaceHigh,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(module.icon, color: WsColors.teal),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(module.name,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w700)),
              ),
              IconButton(
                tooltip: 'Module settings',
                icon: const Icon(Icons.build_rounded, size: 20),
                onPressed: () => showSoon(context, 'step 3'),
              ),
              Switch(
                value: module.enabled,
                onChanged: (v) =>
                    ref.read(modulesProvider.notifier).toggle(module.id, v),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text('Author: ${module.author}',
              style: const TextStyle(color: WsColors.textDim)),
          Text('Version: ${module.version}',
              style: const TextStyle(color: WsColors.textDim)),
          const SizedBox(height: 6),
          Text(module.description),
          const Divider(height: 24, color: WsColors.line),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton.icon(
                onPressed: () => showSoon(context, 'step 3'),
                icon: const Icon(Icons.sync_rounded, size: 18),
                label: const Text('Check for updates'),
              ),
              if (module.builtIn)
                const Text('Built-in',
                    style: TextStyle(color: WsColors.textDim))
              else
                TextButton.icon(
                  onPressed: () => showSoon(context, 'step 3'),
                  icon: const Icon(Icons.delete_outline_rounded, size: 18),
                  label: const Text('Remove'),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
