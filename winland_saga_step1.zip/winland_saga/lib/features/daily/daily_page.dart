import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class DailyPage extends StatelessWidget {
  const DailyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        PageHeader(title: 'Daily', subtitle: 'Quests and daily activities'),
        Expanded(
          child: ComingSoon(
            icon: Icons.checklist_rounded,
            title: 'Daily Assistant',
            description: 'Your daily quest checklist, with where to do each one.',
            step: 'step 4',
            features: ['Quest checklist with locations','Candle Cake and daily activities','Automatic reset each day'],
          ),
        ),
      ],
    );
  }
}
