import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class CandlesPage extends StatelessWidget {
  const CandlesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SubPage(
      title: 'Candles',
      child: ComingSoon(
        icon: Icons.local_fire_department_rounded,
        title: 'Candle Tracker',
        description: 'Count candles and plan how to reach your next item.',
        step: 'step 4',
        features: ['Regular and seasonal candles','Candles needed for an item','Daily progress and time estimate','Saved candle routes'],
      ),
    );
  }
}
