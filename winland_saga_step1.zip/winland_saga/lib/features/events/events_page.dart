import 'package:flutter/material.dart';
import '../../shared/page_chrome.dart';

class EventsPage extends StatelessWidget {
  const EventsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        PageHeader(title: 'Events', subtitle: 'Seasons, spirits and shards'),
        Expanded(
          child: ComingSoon(
            icon: Icons.event_rounded,
            title: 'Event Center',
            description: 'Everything that is coming up, with countdowns and alerts.',
            step: 'step 5',
            features: ['Season calendar and yearly events','Traveling Spirit and Shard timers','Alerts before start and end'],
          ),
        ),
      ],
    );
  }
}
