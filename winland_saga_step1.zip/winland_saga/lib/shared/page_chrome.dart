import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../app/theme.dart';

void showSoon(BuildContext context, String step) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text('Coming in $step')));
}

/// Header used by the five main tabs.
class PageHeader extends StatelessWidget {
  const PageHeader({super.key, required this.title, this.subtitle});
  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 8, 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w700)),
                if (subtitle != null)
                  Text(subtitle!,
                      style: const TextStyle(color: WsColors.textDim)),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Search',
            icon: const Icon(Icons.search_rounded),
            onPressed: () => context.push('/search'),
          ),
          IconButton(
            tooltip: 'More',
            icon: const Icon(Icons.apps_rounded),
            onPressed: () => context.push('/more'),
          ),
        ],
      ),
    );
  }
}

/// Scaffold used by pages opened from the "More" menu.
class SubPage extends StatelessWidget {
  const SubPage({super.key, required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(child: child),
    );
  }
}

/// Placeholder body for features that are built in later steps.
class ComingSoon extends StatelessWidget {
  const ComingSoon({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    required this.step,
    this.features = const [],
  });

  final IconData icon;
  final String title;
  final String description;
  final String step;
  final List<String> features;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: WsColors.teal.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 34, color: WsColors.teal),
            ),
            const SizedBox(height: 18),
            Text(title,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(description,
                textAlign: TextAlign.center,
                style: const TextStyle(color: WsColors.textDim)),
            const SizedBox(height: 14),
            Chip(
              label: Text('Built in $step'),
              backgroundColor: WsColors.surfaceHigh,
              side: const BorderSide(color: WsColors.line),
            ),
            const SizedBox(height: 10),
            for (final f in features)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle_outline,
                        size: 18, color: WsColors.amber),
                    const SizedBox(width: 8),
                    Flexible(child: Text(f)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
