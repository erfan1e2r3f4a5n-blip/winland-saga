import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// A Winland Saga module: a self-contained helper feature that can be
/// switched on/off. Step 3 adds JSON module packs on top of this.
class ModuleInfo {
  const ModuleInfo({
    required this.id,
    required this.name,
    required this.author,
    required this.version,
    required this.description,
    required this.icon,
    this.builtIn = true,
    this.enabled = true,
  });

  final String id;
  final String name;
  final String author;
  final String version;
  final String description;
  final IconData icon;
  final bool builtIn;
  final bool enabled;

  ModuleInfo copyWith({bool? enabled}) => ModuleInfo(
        id: id,
        name: name,
        author: author,
        version: version,
        description: description,
        icon: icon,
        builtIn: builtIn,
        enabled: enabled ?? this.enabled,
      );
}

class ModulesNotifier extends Notifier<List<ModuleInfo>> {
  @override
  List<ModuleInfo> build() => const [
        ModuleInfo(
          id: 'candle_tracker',
          name: 'Candle Tracker',
          author: 'Winland Saga',
          version: '0.1.0',
          description:
              'Track candles, costs and daily progress for regular and seasonal candles.',
          icon: Icons.local_fire_department_rounded,
        ),
        ModuleInfo(
          id: 'daily_assistant',
          name: 'Daily Assistant',
          author: 'Winland Saga',
          version: '0.1.0',
          description:
              'Daily quest checklist with locations and an automatic reset every day.',
          icon: Icons.checklist_rounded,
        ),
        ModuleInfo(
          id: 'event_center',
          name: 'Event Center',
          author: 'Winland Saga',
          version: '0.1.0',
          description:
              'Seasons, Traveling Spirits, Shards and events with countdowns and alerts.',
          icon: Icons.event_rounded,
        ),
        ModuleInfo(
          id: 'collection_tracker',
          name: 'Collection Tracker',
          author: 'Winland Saga',
          version: '0.1.0',
          description: 'Record the items you own and see how complete each category is.',
          icon: Icons.inventory_2_rounded,
        ),
        ModuleInfo(
          id: 'floating_assistant',
          name: 'Floating Assistant',
          author: 'Winland Saga',
          version: '0.1.0',
          description:
              'A small overlay with timers, checklist and notes. It never touches the game.',
          icon: Icons.picture_in_picture_alt_rounded,
          enabled: false,
        ),
      ];

  void toggle(String id, bool value) {
    state = [
      for (final m in state) m.id == id ? m.copyWith(enabled: value) : m,
    ];
  }
}

final modulesProvider =
    NotifierProvider<ModulesNotifier, List<ModuleInfo>>(ModulesNotifier.new);
