import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';

import '../features/candles/candles_page.dart';
import '../features/collection/collection_page.dart';
import '../features/community/community_page.dart';
import '../features/daily/daily_page.dart';
import '../features/dashboard/dashboard_page.dart';
import '../features/events/events_page.dart';
import '../features/map/map_page.dart';
import '../features/modules/modules_page.dart';
import '../features/more/more_page.dart';
import '../features/route_builder/route_builder_page.dart';
import '../features/search/search_page.dart';
import '../features/settings/settings_page.dart';
import '../features/shell/app_shell.dart';
import '../features/spirits/spirits_page.dart';

GoRoute _r(String path, Widget Function() page) =>
    GoRoute(path: path, builder: (context, state) => page());

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    StatefulShellRoute.indexedStack(
      builder: (context, state, shell) => AppShell(shell: shell),
      branches: [
        StatefulShellBranch(routes: [_r('/', () => const DashboardPage())]),
        StatefulShellBranch(routes: [_r('/daily', () => const DailyPage())]),
        StatefulShellBranch(routes: [_r('/map', () => const MapPage())]),
        StatefulShellBranch(routes: [_r('/events', () => const EventsPage())]),
        StatefulShellBranch(
            routes: [_r('/modules', () => const ModulesPage())]),
      ],
    ),
    _r('/more', () => const MorePage()),
    _r('/search', () => const SearchPage()),
    _r('/candles', () => const CandlesPage()),
    _r('/spirits', () => const SpiritsPage()),
    _r('/collection', () => const CollectionPage()),
    _r('/routes', () => const RouteBuilderPage()),
    _r('/community', () => const CommunityPage()),
    _r('/settings', () => const SettingsPage()),
  ],
);
