class AppConstants {
  static const appName = 'Winland Saga';
  static const version = '0.1.0';
}
