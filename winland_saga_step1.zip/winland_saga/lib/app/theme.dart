import 'package:flutter/material.dart';

class WsColors {
  static const bg = Color(0xFF0C0F13);
  static const surface = Color(0xFF141920);
  static const surfaceHigh = Color(0xFF1C232C);
  static const line = Color(0xFF28313D);
  static const teal = Color(0xFF1FD1C0);
  static const amber = Color(0xFFFFB066);
  static const text = Color(0xFFE8ECF1);
  static const textDim = Color(0xFF8D98A7);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: WsColors.teal,
    brightness: Brightness.dark,
  ).copyWith(
    primary: WsColors.teal,
    secondary: WsColors.amber,
    surface: WsColors.surface,
    onSurface: WsColors.text,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: WsColors.bg,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: WsColors.text,
      displayColor: WsColors.text,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: WsColors.bg,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: WsColors.surface,
      indicatorColor: WsColors.teal.withOpacity(0.18),
      labelTextStyle: const WidgetStatePropertyAll(
        TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? WsColors.bg : WsColors.textDim,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected)
            ? WsColors.teal
            : WsColors.surfaceHigh,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: WsColors.surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: WsColors.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: WsColors.line),
      ),
    ),
  );
}
