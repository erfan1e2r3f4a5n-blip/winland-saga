/// Every feature that has searchable data implements [SearchSource].
/// The global search (step 4+) collects entries from all sources into one
/// in-memory index and rebuilds it whenever a data pack is updated.
enum SearchKind { spirit, item, location, event, candle, quest, other }

class SearchEntry {
  const SearchEntry({
    required this.id,
    required this.kind,
    required this.title,
    this.aliases = const [],
    required this.route,
  });
  final String id;
  final SearchKind kind;
  final String title;
  final List<String> aliases;
  final String route; // where to go when the result is tapped
}

abstract class SearchSource {
  Future<List<SearchEntry>> entries();
}
