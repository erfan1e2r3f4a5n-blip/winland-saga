/// Describes one downloadable data pack (candles, spirits, events, ...).
/// The remote manifest lists packs; the app downloads only the ones whose
/// [version] is newer than the stored copy. See docs/ARCHITECTURE.md.
class DataPackInfo {
  const DataPackInfo({
    required this.name,
    required this.version,
    required this.url,
    required this.sha256,
    required this.schema,
    this.minAppVersion = '0.1.0',
  });

  final String name;
  final int version;
  final String url;
  final String sha256;
  final int schema;
  final String minAppVersion;

  factory DataPackInfo.fromJson(Map<String, dynamic> j) => DataPackInfo(
        name: j['name'] as String,
        version: j['version'] as int,
        url: j['url'] as String,
        sha256: j['sha256'] as String,
        schema: j['schema'] as int,
        minAppVersion: (j['minAppVersion'] as String?) ?? '0.1.0',
      );
}
