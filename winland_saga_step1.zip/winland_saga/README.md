# Winland Saga (step 1: skeleton)
See the run instructions in the chat. The project builds an Android APK through GitHub Actions (.github/workflows/build.yml).
